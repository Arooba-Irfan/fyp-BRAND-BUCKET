import React from 'react'
import { connect } from 'react-redux'
import { calculateTotal } from '../../utility/checkout'
import CheckoutListItem from '../CheckoutListItem/CheckoutListItem'

const CheckoutList = ({cartItems}) => {
    return (
        <div>
            {cartItems.map((cart)=> <CheckoutListItem key={cart.id} {...cart}/>)}
        </div>
    )
}

var mapState = (state) => ({
    cartItems: state.cart
})

export default connect(mapState)(CheckoutList)
