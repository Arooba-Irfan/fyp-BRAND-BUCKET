import React from 'react'
import { connect } from 'react-redux'
import { addToCart, removeFromCart, deleteFromCart } from '../../Redux/cart/cartActions';

const CartListItem = ({addToCart,removeFromCart,deleteFromCart,...cart}) => {
    var {title='title', cost=50, quantity=0,id} = cart
    return (
        <div>
            <h1>{title} - {cost} - <button onClick={()=>deleteFromCart(id)}> x </button></h1>
            <h2><button onClick={()=>addToCart(cart)} >+</button>  {quantity} <button onClick={()=>removeFromCart(cart)}>-</button></h2>
        </div>
    )
}

var actions = {
    addToCart,
    removeFromCart,
    deleteFromCart
}

export default connect(null,actions)(CartListItem)
