import React from 'react'
import { connect } from 'react-redux'
import { Link } from 'react-router-dom'
import { generateOrder } from '../../Redux/orders/orderActions'
import CartList from '../CartList/CartList'
import CategoryList from '../CategoryList/CategoryList'

const Cart = ({generateOrder}) => {
    return (
        <div>
            <h1>Cart</h1>
            <CartList/>
            <button onClick = {generateOrder}>CheckOut</button>
        </div>
    )
}

var actions = {
    generateOrder
}

export default connect(null,actions)(Cart)
