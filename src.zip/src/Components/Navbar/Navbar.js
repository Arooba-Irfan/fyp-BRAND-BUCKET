import './Navbar.css'
import React from 'react'
import Header from '../Header/Header'
import { Link } from 'react-router-dom'
import { connect } from 'react-redux'
import { signout } from "../../Redux/auth/authAction";


const MenuItem=({children,to="#",...restProps})=>{
    return(
        <div {...restProps} className="menuItem">
            <Link to={to}>

                <Header fontWeight="semi-bold" fontSize="20" style={{cursor:"pointer", display:"inline"}}>{children}</Header>
            </Link>      
        </div>
    )
}

const Navbar = ({auth,signout}) => {
    return (
        <div className="navbar">
            <MenuItem to ="/">LOGO</MenuItem>
            <MenuItem to="/categories">SHOP</MenuItem>
            <MenuItem>CART</MenuItem>
            {auth ? <MenuItem to="/authentication" onClick={signout}>LOGOUT</MenuItem>:<MenuItem to="/authentication">LOGIN</MenuItem>}
        </div>
    )
}

var actions={
    signout
}
var mapState=(state)=>({
    auth: state.auth
})

export default connect(mapState,actions)(Navbar)
