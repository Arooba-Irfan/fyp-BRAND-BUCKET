import React from 'react'
import { connect } from 'react-redux'
import CartListItem from '../CartListItem/CartListItem'

const CartList = ({cartItems}) => {
    return (
        <div>
            {cartItems.map((cart)=> <CartListItem key={cart.id} {...cart}/>)}
        </div>
    )
}

var mapState = (state) => ({
    cartItems: state.cart
})

export default connect(mapState)(CartList)