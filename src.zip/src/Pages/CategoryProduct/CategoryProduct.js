import React , { useEffect } from 'react'
import { connect } from 'react-redux'
import ProductCard from '../../Components/ProductCard/ProductCard';
import { fetchCategoryProducts, clearProducts} from '../../Redux/products/productActions';

const CategoryProduct = ({match:{params: {category}}, fetchCategoryProducts, clearProducts, products}) => {
  console.log(products)

  useEffect(() => {
    //CDM
    fetchCategoryProducts(category)
    return () => {
      clearProducts()
    }
  }, [])
    return (
        <div>
          <h1> {category} Product Page</h1>
          {products.map((product)=> <ProductCard key={product.title} {...product}/>)}  
        </div>
    )
}

var actions = {
  fetchCategoryProducts,
  clearProducts
}

var mapState = (state) => ({
  products:state.product
})

export default connect(mapState,actions)(CategoryProduct)