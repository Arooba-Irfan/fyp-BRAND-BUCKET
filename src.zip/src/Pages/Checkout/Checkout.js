import React, { useState } from 'react'
import { connect } from 'react-redux'
import { calculateTotal } from '../../utility/checkout'
import CheckoutList from '../../Components/CheckoutList/CheckoutList'
import OrderForm from '../../Components/OrderForm/OrderForm'

const Checkout = ({total}) => {
    var [ShippInfoShown,setShipInfoShown] = useState(false)
    return (
        <div>
          <h1>Checkout Page</h1>
          <CheckoutList/>
          <h1>Total Amount {total}</h1> 
          {ShippInfoShown && <OrderForm/>}
          <button onClick={()=>{setShipInfoShown(!ShippInfoShown)}}>Proceed & Pay</button> 
        </div>
    )
}

var mapState = (state) => ({
  total: calculateTotal(state.cart)
})

export default connect(mapState)(Checkout)