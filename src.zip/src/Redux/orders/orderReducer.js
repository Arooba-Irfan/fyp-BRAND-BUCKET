
var initialState = []

var orderReducer = (state=initialState, actions) => {
    var {type,payload}=actions
    switch (type) {
        default:
            return initialState
    }
}

export default orderReducer