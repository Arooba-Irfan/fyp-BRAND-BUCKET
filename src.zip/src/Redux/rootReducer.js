import {combineReducers } from 'redux'
import auhtReducer from './auth/authReducer'
import cartReducer from './cart/cartReducer';
import orderReducer from './orders/orderReducer';
import productReducer from "./products/productReducer";

var rootReducer = combineReducers({
    auth:auhtReducer,
    product:productReducer,
    cart: cartReducer,
    order: orderReducer
})
export default rootReducer